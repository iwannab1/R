package com.raonbit.edu.ml

import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.sql.SparkSession

object CTRPredictor extends App{

  case class CtrRecord(label:Double, i1: Double, i2: Double, i3: Double, i4: Double, i5: Double, i6: Double
                       , i7: Double, i8: Double, i9: Double, i10: Double, i11: Double, i12: Double, i13: Double
                       , c1:String, c2:String, c3:String, c4:String, c5:String, c6:String, c7:String, c8:String, c9:String, c10:String
                       , c11:String, c12:String, c13:String, c14:String, c15:String, c16:String, c17:String, c18:String, c19:String, c20:String
                       , c21:String, c22:String, c23:String, c24:String, c25:String, c26:String)

  val spark = SparkSession
    .builder()
    .master("local[*]")
    .config("spark.testing.memory", "1471859200")  // BUG
    .config("spark.sql.warehouse.dir", "file:///d:/kodb/SparkProcess/spark-warehouse")  // BUG
      .config("spark.driver.memory", "1g")
    .config("spark.executor.memory", "1g")
    .appName("CTRPredictor")
    .getOrCreate()

  import spark.implicits._


  def s2d(str:String):Double = {
    str.trim match {
      case "" => 0.0
      case _ => str.trim.toDouble
    }
  }

  def makeNull(str:String):String = {
    str.trim match {
      case "" => null
      case _ => str.trim
    }
  }


  val dacDF = spark.sparkContext.textFile("src/main/resources/dac_sample.txt").map(_.split("\t", -1))
    .map(v => CtrRecord(s2d(v(0)) , s2d(v(1)), s2d(v(2)), s2d(v(3)), s2d(v(4)), s2d(v(5)), s2d(v(6)), s2d(v(7))
                                        , s2d(v(8)), s2d(v(9)), s2d(v(10)), s2d(v(11)), s2d(v(12)), s2d(v(13))
                                        ,makeNull(v(14)),makeNull(v(15)),makeNull(v(16)),makeNull(v(17)),makeNull(v(18)),makeNull(v(19)),makeNull(v(20)),makeNull(v(21)),makeNull(v(22)),makeNull(v(23)),makeNull(v(24)),makeNull(v(25)),makeNull(v(26))
                                       ,makeNull(v(27)),makeNull(v(28)),makeNull(v(29)),makeNull(v(30)),makeNull(v(31)),makeNull(v(32)),makeNull(v(33)),makeNull(v(34)),makeNull(v(35)),makeNull(v(36)),makeNull(v(37)),makeNull(v(38)),makeNull(v(39)))).toDF()

  dacDF.createOrReplaceTempView("clicks")
  println(dacDF.count())


  // drop null
  val dacDF2 = dacDF.na.drop()

  // data split
    val weights = Array(0.7, 0.3)
    val seed = 1234

  val splits = dacDF2.randomSplit(weights, seed)
  val trainDF = splits(0).cache()
  val testDF = splits(1).cache()


  // convert category to numerical ( one hot encoding )
  import org.apache.spark.ml.feature.{StringIndexer, VectorAssembler,OneHotEncoder}
  import org.apache.spark.ml.{Pipeline, PipelineStage}

  val categoryColumn = Array("c1","c2", "c3","c4","c5", "c6","c7","c8", "c9", "c10"
                                                      ,"c11","c12", "c13","c14","c15", "c16","c17","c18", "c19", "c20"
                                                      ,"c21","c22", "c23","c24","c25", "c26")

  val index_transformers: Array[PipelineStage] = categoryColumn.map(
    cname => new StringIndexer()
      .setInputCol(cname)
      .setOutputCol(s"${cname}_index")
        .setHandleInvalid("skip")
  )

  //encoding columns
  val indexColumns  = categoryColumn.map(_ + "_index")
  val one_hot_encoders: Array[PipelineStage] = indexColumns.map(
    cname => new OneHotEncoder()
      .setInputCol(cname)
      .setOutputCol(s"${cname}_vec")
  )

  val featureColumns = dacDF.columns.filter(_ != "label").map{
    colname => {
     if(colname.startsWith("i"))
       colname
     else
       s"${colname}_index_vec"
    }
  }.toList.toArray[String]

  val assembler = new VectorAssembler()
    .setInputCols(featureColumns)
    .setOutputCol("features")

  val classifier = new LogisticRegression().setMaxIter(10).setRegParam(0.01)

//  import org.apache.spark.ml.classification.{RandomForestClassificationModel, RandomForestClassifier}
//  val classifier = new RandomForestClassifier().setNumTrees(10)


  val pipeline = new Pipeline()
    .setStages(index_transformers ++ one_hot_encoders  :+ assembler :+ classifier)

  // training
  val model = pipeline.fit(trainDF)

  // test
  val output = model.transform(testDF).select("label", "prediction", "rawPrediction", "probability")
  val prediction = output.select("label", "prediction")
  val accuracy = prediction.filter($"label" ===  $"prediction") .count()  / prediction.count.toFloat
  println(accuracy)

  // cross validatation

  import org.apache.spark.ml.evaluation.BinaryClassificationEvaluator
  import org.apache.spark.ml.tuning.ParamGridBuilder
  import org.apache.spark.ml.tuning.CrossValidator

  val evaluator = new BinaryClassificationEvaluator()
  val paramGrid = new ParamGridBuilder().addGrid(classifier.maxIter, Seq(10, 100)).build()
  val numFolds=2

  val crossval = new CrossValidator()
                                    .setEstimator(pipeline)
                                    .setEstimatorParamMaps(paramGrid)
                                    .setEvaluator(evaluator)
                                    .setNumFolds(numFolds)

  val cvModel = crossval.fit(trainDF)
  val cvPrediction = cvModel.transform(testDF).select("label", "prediction")
  val cvAccuracy = cvPrediction.filter($"label" === $"prediction").count() / cvPrediction.count().toFloat
  println(cvAccuracy)


}
