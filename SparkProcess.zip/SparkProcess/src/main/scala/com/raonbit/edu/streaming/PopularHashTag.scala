package com.raonbit.edu.streaming

import java.util.Properties

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.Seconds
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.flume.FlumeUtils

object PopularHashTag {
  def main(args: Array[String]): Unit = {

    val sparkConf = new SparkConf().setAppName("PopularHashTag").setMaster("local[*]")
    sparkConf.set("spark.testing.memory", "1471859200")
    val ssc = new StreamingContext(sparkConf, Seconds(5))
    val stream = FlumeUtils.createStream(ssc, "localhost", 9999, StorageLevel.MEMORY_ONLY_SER_2)

    stream.map(e => "Event:header:" + e.event.get(0).toString
      + "body: " + new String(e.event.getBody.array)).print

    val body = stream.map(e => new String(e.event.getBody.array ))
      val hashTags = body.flatMap( s => s.split(" ").filter(_.length > 3))



            val topCounts60 = hashTags.map((_, 1)).reduceByKeyAndWindow(_ + _, Seconds(60))
              .map{case (topic, count) => (count, topic)}
              .transform(_.sortByKey(false))

            val topCounts10 = hashTags.map((_, 1)).reduceByKeyAndWindow(_ + _, Seconds(10))
              .map{case (topic, count) => (count, topic)}
              .transform(_.sortByKey(false))


            // Print popular hashtags
            topCounts60.foreachRDD(rdd => {
              val topList = rdd.take(10)
              println("\nPopular topics in last 60 seconds (%s total):".format(rdd.count()))
              topList.foreach{case (count, tag) => println("%s (%s tweets)".format(tag, count))}
            })

            topCounts10.foreachRDD(rdd => {
              val topList = rdd.take(10)
              println("\nPopular topics in last 10 seconds (%s total):".format(rdd.count()))
              topList.foreach{case (count, tag) => println("%s (%s tweets)".format(tag, count))}
            })

        ssc.start()
        ssc.awaitTermination()
  }
}
