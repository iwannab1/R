package com.raonbit.edu.sql

import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types._


object RddDataframeDataset extends  App {

  case class Person(name: String, age: Long)

  val spark = SparkSession
    .builder()
    .master("local")
    .config("spark.testing.memory", "1471859200")  // BUG
    .config("spark.sql.warehouse.dir", "file:///d:/kodb/SparkProcess/spark-warehouse")  // BUG
    .appName("RDD vs. DF vs. DS")
    .getOrCreate()

  import spark.implicits._

  val df = spark.read.json("src/main/resources/people.json")
  val ds = spark.read.json("src/main/resources/people.json").as[Person]

  val selectedDF = df.select("name")
  val selectedDS = ds.map(_.name)

  println("Dataframe optimized plan")
  println(selectedDF.queryExecution.optimizedPlan.numberedTreeString)
  println("Dataset optimized plan")
  println(selectedDS.queryExecution.optimizedPlan.numberedTreeString)


  val rdd = spark.sparkContext.textFile("src/main/resources/README.md")
  val dataset = spark.read.json("src/main/resources/README.md").as[String]

  // do count
  println("count ")
  println(rdd.count())
  println(dataset.count())

  // wordcount
  println(" wordcount ")

  val wordsRDD = rdd.flatMap(value => value.split("\\s+"))
  val wordsPair = wordsRDD.map(word => (word,1))
  val wordCount = wordsPair.reduceByKey(_+_)
  println(wordCount.collect.toList)

  val wordsDs = dataset.flatMap(value => value.split("\\s+"))
  val wordsPairDs = wordsDs.groupByKey(value => value)
  val wordCountDs = wordsPairDs.count
  wordCountDs.show()

  //cache
  rdd.cache()
  ds.cache()

  //filter

  val filteredRDD = wordsRDD.filter(value => value =="Spark")
  println(filteredRDD.collect().toList)

  val filteredDS = wordsDs.filter(value => value =="Spark")
  filteredDS.show()


  //map partitions

  val mapPartitionsRDD = rdd.mapPartitions(iterator => List(iterator.count(value => true)).iterator)
  println(s" the count each partition is ${mapPartitionsRDD.collect().toList}")

  val mapPartitionsDs = dataset.mapPartitions(iterator => List(iterator.count(value => true)).iterator)
  mapPartitionsDs.show()

  //converting to each other
  val dsToRDD = dataset.rdd
  println(dsToRDD.collect().toList)

  val rddStringToRowRDD = rdd.map(value => Row(value))
  val dfschema = StructType(Array(StructField("value",StringType)))
  val rddToDF = spark.createDataFrame(rddStringToRowRDD,dfschema)
  val rDDToDataSet = rddToDF.as[String]
  rDDToDataSet.show()

  // double based operation
  val doubleRDD = spark.sparkContext.makeRDD(List(1.0,5.0,8.9,9.0))
  val rddSum =doubleRDD.sum()
  val rddMean = doubleRDD.mean()

  println(s"sum is $rddSum")
  println(s"mean is $rddMean")

  val rowRDD = doubleRDD.map(value => Row.fromSeq(List(value)))
  val schema = StructType(Array(StructField("value",DoubleType)))
  val doubleDS = spark.createDataFrame(rowRDD,schema)

  import org.apache.spark.sql.functions._
  doubleDS.agg(sum("value")).show()
  doubleDS.agg(mean("value")).show()

  //reduceByKey API
  val reduceCountByRDD = wordsPair.reduceByKey(_+_)
  val reduceCountByDs = wordsPairDs.mapGroups((key,values) =>(key,values.length))

  println(reduceCountByRDD.collect().toList)
  println(reduceCountByDs.collect().toList)

  //reduce function
  val rddReduce = doubleRDD.reduce((a,b) => a +b)
  val dsReduce = doubleDS.reduce((row1,row2) =>Row(row1.getDouble(0) + row2.getDouble(0)))

  println("rdd reduce is " +rddReduce +" dataset reduce "+dsReduce)



}
