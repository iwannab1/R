package com.raonbit.edu.sql

import org.apache.spark.sql.SparkSession

object ParquetFile extends App {

  val spark = SparkSession
    .builder()
    .master("local")
    .config("spark.testing.memory", "1471859200")  // BUG
    .config("spark.sql.warehouse.dir", "file:///d:/kodb/SparkProcess/spark-warehouse")  // BUG
    .appName("Parquet Handle")
    .getOrCreate()

  import spark.implicits._

  val parquetFileDF = spark.read.parquet("src/main/resources/users.parquet")

  parquetFileDF.createOrReplaceTempView("parquetFile")
  val namesDF = spark.sql("SELECT Name FROM parquetFile where Name like 'B%'")
  namesDF.map(v => "Name: " + v(0)).show()



 // partitioned data
  val squaresDF = spark.sparkContext.makeRDD(1 to 5).map(i => (i, i * i)).toDF("value", "square")
  squaresDF.write.parquet("src/main/resources/test_table/key=1")

  val cubesDF = spark.sparkContext.makeRDD(6 to 10).map(i => (i, i * i * i)).toDF("value", "cube")
  cubesDF.write.parquet("src/main/resources/test_table/key=2")

  // merge scheme
  val mergedDF = spark.read.option("mergeSchema", "true").parquet("src/main/resources/test_table")
  mergedDF.printSchema()

  mergedDF.createOrReplaceTempView("mergeTable")
  spark.sql("select * from mergeTable").show

}
