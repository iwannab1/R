package com.raonbit.edu.nifi

import java.nio.charset.StandardCharsets

import org.apache.nifi.remote.client.SiteToSiteClient
import org.apache.nifi.spark.NiFiReceiver
import org.apache.spark.SparkConf
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.{Seconds, StreamingContext}

object NifiSparkWordCount extends App {

  val conf = new SiteToSiteClient.Builder().url("http://localhost:8080/nifi").portName("spark").buildConfig()
  val config = new SparkConf().setAppName("Nifi_Spark_Data")
  val ssc = new StreamingContext(config, Seconds(10))
  val lines = ssc.receiverStream(new NiFiReceiver(conf, StorageLevel.MEMORY_ONLY))
  val wc= lines.map(dataPacket => new String(dataPacket.getContent, StandardCharsets.UTF_8).toString)
//                          .flatMap(_.split(" "))
//                          .map(x => (x, 1)).reduceByKey(_ + _)
//  wc.saveAsTextFiles("file:///tmp/dest/woud.count")
  wc.print()
  ssc.start()
  ssc.awaitTermination()

}
